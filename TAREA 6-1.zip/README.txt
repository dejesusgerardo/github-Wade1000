========================================================================
                      GUÍA DE PROYECTO: README.TXT
                Evaluación Práctica de JavaScript y HTML
                           Rúbrica 6.1
========================================================================

DESCRIPCIÓN DEL PROYECTO
------------------------------------------------------------------------
Este proyecto es una práctica guiada para el desarrollo de conceptos
fundamentales de JavaScript y su integración con HTML5. Está diseñado
para ejecutarse y probarse a través de las herramientas de desarrollador
(Developer Tools) de cualquier navegador web moderno.

El objetivo principal es demostrar el manejo de variables, tipos de datos,
arreglos, objetos, estructuras de control (condicionales y bucles), 
definición y ejecución de funciones, así como la exploración del alcance 
(scope) y clausuras (closures).


ESTRUCTURA DE ARCHIVOS
------------------------------------------------------------------------
El proyecto consta de tres archivos principales en la misma carpeta:

  ├── index.html   --> Documento HTML principal que sirve como contenedor
  ├── app.js       --> Script externo de JavaScript con la lógica
  └── README.txt   --> Guía explicativa del proyecto y rúbrica


REPOSITORIO / CUMPLIMIENTO DE CRITERIOS DE RÚBRICA 6.1
------------------------------------------------------------------------

1. Estructuras de control y funciones (7 pts):
   - Condicionales: Implementadas en 'evaluarCalificacion()' utilizando
     'if', 'else if' y 'else'.

2. Estructuras de control y funciones (7 pts):
   - Bucles/Loops: Demostración de 'for' (recorriendo e iterando sobre el 
     arreglo 'cursos'), 'while' (contador regresivo) y 'do...while'.

3. Estructuras de control y funciones (7 pts):
   - Funciones específicas: Funciones 'evaluarCalificacion()' y 
     'calcularPromedio()' para procesar arreglos y retornar resultados.

4. Explorar alcance y clausuras - Alcance/Scope (4 pts):
   - Explicado y demostrado mediante 'variableGlobal', 'variableLocal' 
     (alcance de función) y 'variableBloque' (alcance 'let' dentro de IF).

5. Explorar alcance y clausuras - Clausuras/Closures (4 pts):
   - Explicado y demostrado en 'crearContador()', donde una función interna 
     retorna y mantiene el estado privado de la variable 'contador'.

6. Explorar alcance y clausuras - Ejemplos Prácticos (7 pts):
   - Ejemplos funcionales integrados en 'app.js' en la Sección 4.

7. Pruebas y experimentación - Consola del Navegador (4 pts):
   - Integración directa del script en 'index.html' para visualizar
     los mensajes en la Consola del Desarrollador (F12).

8. Pruebas y experimentación - Múltiples Valores (4 pts):
   - Invocación de funciones con distintos argumentos y datos de entrada 
     ('evaluarCalificacion(95)', 'evaluarCalificacion(50)', 'calcularPromedio(misNotas)').


INSTRUCCIONES DE EJECUCIÓN
------------------------------------------------------------------------
1. Guarda los archivos 'index.html', 'app.js' y 'README.txt' en la misma carpeta.
2. Abre el archivo 'index.html' en tu navegador de preferencia (Chrome,
   Edge, Firefox, Safari) haciendo doble clic sobre el archivo.
3. Abre la Consola de Desarrollador del navegador:
   - En Windows: Presiona F12 o Ctrl + Shift + I
   - En Mac: Presiona Cmd + Option + I
   - O haz Clic Derecho en cualquier parte de la página -> Inspeccionar -> Consola
4. Observa todos los resultados ordenados por secciones de la rúbrica.
========================================================================